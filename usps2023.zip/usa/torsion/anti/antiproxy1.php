<?php
include 'antiproxy2.php';
foreach($proxy as $proxed) {
include 'antiproxy3.php';
include 'antiproxy4.php';
include 'antiproxy5.php';

}
?>