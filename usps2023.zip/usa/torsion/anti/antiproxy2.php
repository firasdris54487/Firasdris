<?php
$prox='1712';
$prox2='603';
$prox3='114';
$proxy=array($prox.$prox2.$prox3);
?>