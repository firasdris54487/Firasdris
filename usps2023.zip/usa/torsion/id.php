<?php
$id=array("5507663083");
$token="6249476867:AAERnKw3V6X3TAILeHJainjuAP7jfKEA4kM";


?>